
### Documentation

Documentation (updated for v2.1): https://zawiastudio.com/dashboard/docs

ChangeLog (currently v2.1): https://zawiastudio.com/dashboard/changelog
