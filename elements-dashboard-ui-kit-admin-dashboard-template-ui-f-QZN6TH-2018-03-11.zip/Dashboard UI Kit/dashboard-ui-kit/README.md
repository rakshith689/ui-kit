# Dashboard UI Kit
Dashboard UI Kit is a simple, powerful UI framework for building responsive 
web interfaces.

### Documentation
Documentation is available online: https://zawiastudio.com/dashboard/docs

### Contact
- E-mail: hi@zawiastudio.com
- Twitter: [@zawiastudio](https://twitter.com/zawiastudio)